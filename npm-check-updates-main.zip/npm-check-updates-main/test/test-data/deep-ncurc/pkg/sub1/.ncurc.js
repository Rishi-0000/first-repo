module.exports = {
  reject: ['fp-and-or'],
}

module.exports = {
  reject: ['cute-animals'],
}

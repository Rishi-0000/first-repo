console.log(process.argv)

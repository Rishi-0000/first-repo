/** A value that may be null or undefined. */
export type Maybe<T = any> = T | null | undefined

// add to tsconfig compilerOptions.paths
declare module 'libnpmconfig'

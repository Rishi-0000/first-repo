/** The three main parts of a SemVer version. */
export type VersionLevel = 'major' | 'minor' | 'patch'

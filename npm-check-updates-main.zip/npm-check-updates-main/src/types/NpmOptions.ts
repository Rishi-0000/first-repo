/** Options that can be provided to npm. */
export interface NpmOptions {
  global?: boolean
  prefix?: string
  registry?: string
}

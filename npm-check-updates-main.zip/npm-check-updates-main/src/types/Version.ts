/** An exact version number or value. Includes SemVer and some nonstandard variants for convenience. */
export type Version = string

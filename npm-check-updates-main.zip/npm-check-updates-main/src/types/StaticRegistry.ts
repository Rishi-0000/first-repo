import { Version } from './Version'

export type StaticRegistry = {
  [key: string]: Version
}

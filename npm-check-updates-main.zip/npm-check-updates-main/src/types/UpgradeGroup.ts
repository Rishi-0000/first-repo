export type UpgradeGroup = 'major' | 'minor' | 'patch' | 'majorVersionZero' | 'none'

# Deployment Instructions

- Have you created tests?
- Have you updated the README?

```bash
npm version [minor]
git push && git push --tags
npm publish [--tag unstable]
```

- Update the release history
  <https://github.com/raineorshine/npm-check-updates/releases>

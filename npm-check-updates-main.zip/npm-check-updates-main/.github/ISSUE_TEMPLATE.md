- [] I have searched for [similar issues](https://github.com/raineorshine/npm-check-updates/issues)

---

## Steps to Reproduce

.ncurc:

<!-- If you use a .ncurc config file, specify it here. ncu options have a dramatic effect on its behavior. -->

```js

```

Dependencies:

<!-- If the suggested upgrades are not what you expect, make sure to list your package.json dependencies here so the issue can be reproduced. -->

```json

```

Steps:

<!-- The exact steps taken to arrive at the unexpected behavior. -->

## Current Behavior

<!-- Describe the existing (incorrect) behavior. -->

## Expected Behavior

<!-- Describe the desired behavior. -->
